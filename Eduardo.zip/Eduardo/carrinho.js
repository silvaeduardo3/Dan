document.addEventListener("DOMContentLoaded", function () {
  function atualizarSubtotal() {
    let total = 0;
    const produtos = document.querySelectorAll(".produto");

    produtos.forEach((produto) => {
      const quantidadeElem = produto.querySelector(".quantidade");
      const precoTexto = produto.querySelector(
        ".descricao_img p:last-child"
      ).textContent;
      const preco = parseFloat(precoTexto.replace("R$", "").replace(",", "."));
      const quantidade = parseInt(quantidadeElem.textContent);
      const totalProduto = preco * quantidade;

      produto.querySelector("h6").textContent = `R$ ${totalProduto
        .toFixed(2)
        .replace(".", ",")}`;
      total += totalProduto;
    });

    document.querySelector(
      "footer .total h5:last-child"
    ).textContent = `R$ ${total.toFixed(2).replace(".", ",")}`;
    document.querySelector(
      ".qtd_itens"
    ).textContent = `${produtos.length} itens`;
  }

  document.querySelectorAll(".mais").forEach((botao) => {
    botao.addEventListener("click", function () {
      const quantidadeElem = this.parentElement.querySelector(".quantidade");
      let quantidade = parseInt(quantidadeElem.textContent);
      quantidade++;
      quantidadeElem.textContent = quantidade;
      atualizarSubtotal();
    });
  });

  document.querySelectorAll(".menos").forEach((botao) => {
    botao.addEventListener("click", function () {
      const quantidadeElem = this.parentElement.querySelector(".quantidade");
      let quantidade = parseInt(quantidadeElem.textContent);
      if (quantidade > 1) {
        quantidade--;
        quantidadeElem.textContent = quantidade;
        atualizarSubtotal();
      }
    });
  });

  document.querySelectorAll(".btn_deletar").forEach((botao) => {
    botao.addEventListener("click", function () {
      const produto = this.closest(".produto");
      produto.remove();
      atualizarSubtotal();
    });
  });

  atualizarSubtotal(); // Atualiza ao carregar
});
